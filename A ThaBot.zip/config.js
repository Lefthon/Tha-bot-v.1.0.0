/*/
import { watchFile, unwatchFile } from 'fs'
import fs from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

//════════════════════════════//
//       BOT CONFIGURATION     //
//════════════════════════════//

/**
 * @type {Object} Global Configuration
 */
const config = {

  //═══════ Owner Settings ═══════//
  owner: [['6282298334109', '「 Lefthon 」', true]],
  mods: ["6285298027445"],    // Moderators
  prems: ["6285298027445"],   // Premium users
  ownerInfo: {
    name: "Lefthon",
    number: "6282298334109"
  },

  //═══════ Bot Identity ═══════//
  bot: {
    name: "ThaBot Й",
    number: "6282298334109",      // Change with your bot number
    version: "beta",
    limits: {
      documentSize: "45000000000",  // 10TB default
      documentPages: "19"
    }
  },

  //═══════ Media & Assets ═══════//
  media: {
    gif: "https://files.catbox.moe/mw3us0.mp4",
    video: "https://files.catbox.moe/8e7clm.mp4",
    icon: "https://files.catbox.moe/0btxr4.jpg",
    thumbnails: [
      "https://files.catbox.moe/7qma1k.jpg",
      "https://files.catbox.moe/2o90fz.jpg"
    ],
    images: [
      "https://files.catbox.moe/4y4h33.jpg",
      "https://files.catbox.moe/c1hizy.jpg"
    ],
    audio: {
      menu: "https://files.catbox.moe/0l80rh.mp3",
      menuAll: "https://files.catbox.moe/2vzbox.mp3",
      owner: "https://files.catbox.moe/kz3oq9.mp3"
    }
  },

  //═══════ Social Links ═══════//
  social: {
    groupChat: "https://chat.whatsapp.com/EgTKbIfNDrU7QasJuRxeEP",
    channel: "https://whatsapp.com/channel/0029Vb615brAzNbywHCyRc1w",
    instagram: "https://www.instagram.com/zass.id_",
    website: "https://www.neolabsofficial.my.id",
    github: "https://github.com/ZassOnee",
    whatsapp: "wa.me/6285298027445"
  },

  //═══════ Channel Info ═══════//
  channel: {
    id: "120363417526801494@newsletter",
    name: "- Thon • Team -"
  },

  //═══════ Watermark Settings ═══════//
  watermark: {
    primary: "© ThaBot 2025",
    secondary: "「 ThaBot Й 」",
    tertiary: "⫹⫺ ThaBot"
  },

  //═══════ Message Templates ═══════//
  messages: {
    wait: "*Tunggu Sebentar Ya Kack ^ω^*",
    error: "*Mohon Maaf Server Kami Sedang Error!*",
    sticker: {
      packName: `ЙThaBot \nЙSource Code Github Lefthon\nЙOwner Number 6282298334109`,
      author: "Lefthon"
    }
  },

  //═══════ RPG System ═══════//
  rpg: {
    multiplier: 69,
    emoticons: {
      agility: '🤸‍♂️',
      arc: '🏹',
      armor: '🥼',
      bank: '🏦',
      bibitanggur: '🍇',
      bibitapel: '🍎',
      bibitjeruk: '🍊',
      bibitmangga: '🥭',
      bibitpisang: '🍌',
      bow: '🏹',
      bull: '🐃',
      cat: '🐈',
      chicken: '🐓',
      common: '📦',
      cow: '🐄',
      crystal: '🔮',
      darkcrystal: '♠️',
      diamond: '💎',
      dog: '🐕',
      dragon: '🐉',
      elephant: '🐘',
      emerald: '💚',
      exp: '✉️',
      fishingrod: '🎣',
      fox: '🦊',
      gems: '🍀',
      giraffe: '🦒',
      gold: '👑',
      health: '❤️',
      horse: '🐎',
      intelligence: '🧠',
      iron: '⛓️',
      keygold: '🔑',
      keyiron: '🗝️',
      knife: '🔪',
      legendary: '🗃️',
      level: '🧬',
      limit: '🌌',
      lion: '🦁',
      magicwand: '⚕️',
      mana: '🪄',
      money: '💵',
      mythic: '🗳️',
      pet: '🎁',
      petFood: '🍖',
      pickaxe: '⛏️',
      pointxp: '📧',
      potion: '🥤',
      rock: '🪨',
      snake: '🐍',
      stamina: '⚡',
      strength: '🦹‍♀️',
      string: '🕸️',
      superior: '💼',
      sword: '⚔️',
      tiger: '🐅',
      trash: '🗑',
      uncommon: '🎁',
      upgrader: '🧰',
      wood: '🪵'
    }
  },

  //═══════ API Keys ═══════//
  apiKeys: {
    global.skizo = 'rafael'
global.key = 'yanzsky'
global.lolkey = 'ElainaAI'
global.lann = 'zassbtz',
global.lol = 'GataDios'
  },

  //═══════ Bot Settings ═══════//
  settings: {
    autoClear: false,
    addReply: true
  }
}

//════════════════════════════//
//     FILE WATCHER SYSTEM    //
//════════════════════════════//
const currentFile = fileURLToPath(import.meta.url)
watchFile(currentFile, () => {
  unwatchFile(currentFile)
  console.log(chalk.redBright("Configuration updated - reloading..."))
  import(`${currentFile}?update=${Date.now()}`)
})
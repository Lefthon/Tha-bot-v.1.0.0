import fetch from 'node-fetch';

const handler = async (m, { conn }) => {
  let ip = await fetch(`https://api.betabotz.eu.org/ip`).then(response => response.text());
  let message = `your ip: ${ip}`;
  m.reply(message);
};

handler.help = ['getip'];
handler.tags = ['info'];
handler.command = /^(getip)$/i;

export default handler;
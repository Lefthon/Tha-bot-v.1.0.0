import fetch from "node-fetch";
import { tekateki } from "@bochilteam/scraper";

const timeout = 120000;

const handler = async (m, { conn, command, usedPrefix }) => {
  conn.tekateki = conn.tekateki || {};
  const id = m.chat;

  if (id in conn.tekateki) {
    conn.reply(
      m.chat,
      "You already have a question to answer!",
      conn.tekateki[id][0]
    );
    return;
  }

  const src = await (
    await fetch(
      "https://raw.githubusercontent.com/qisyana/scrape/main/tekateki.json"
    )
  ).json();

  const json = src[Math.floor(Math.random() * src.length)];
  const caption = `*[ TEKA TEKI ]*
*• Timeout :* 60 seconds
*• Question :* ${json.pertanyaan}
*• Clue :* ${json.jawaban.replace(/[AIUEOaiueo]/g, "_")}

Reply to this message to answer the question.
Type *\`nyerah\`* to surrender.`.trim();

  conn.tekateki[id] = [
    await conn.reply(m.chat, caption, m),
    json,
    setTimeout(() => {
      if (conn.tekateki[id]) {
        conn.sendMessage(
          id,
          {
            text: `Game Over!!
You lose with reason: *[ Timeout ]*

• Answer: *[ ${json.jawaban} ]*`,
          },
          {
            quoted: m,
          }
        );
        delete conn.tekateki[id];
      }
    }, timeout),
  ];
};

handler.before = async (m, { conn }) => {
  conn.tekateki = conn.tekateki || {};
  const id = m.chat;

  if (!m.text || m.isCommand || !conn.tekateki[id]) return;

  const json = conn.tekateki[id][1];
  const reward = global.db.data.users[m.sender] || {};

  if (["nyerah", "surrender"].includes(m.text.toLowerCase())) {
    clearTimeout(conn.tekateki[id][2]);

    conn.sendMessage(
      m.chat,
      {
        text: `Game Over!!
You lose with reason: *[ ${m.text} ]*

• Answer: *[ ${json.jawaban} ]*`,
      },
      {
        quoted: conn.tekateki[id][0],
      }
    );

    delete conn.tekateki[id];
  } else if (m.text.toLowerCase() === json.jawaban.toLowerCase()) {
    reward.money = (reward.money || 0) + 10000;
    reward.limit = (reward.limit || 0) + 10;

    clearTimeout(conn.tekateki[id][2]);

    await conn.sendMessage(
      m.chat,
      {
        text: `Congratulations 🎉
You have successfully guessed the answer!

* *Money:* 10,000+
* *Limit:* 10+

Next question...`,
      },
      {
        quoted: conn.tekateki[id][0],
      }
    );

    delete conn.tekateki[id];
    await conn.appendTextMessage(m, ".tekateki", m.chatUpdate);
  } else {
    conn.sendMessage(m.chat, {
      react: {
        text: "❌",
        key: m.key,
      },
    });
  }
};

handler.help = ["tekateki"];
handler.tags = ["game"];
handler.command = ["tekateki"];
handler.group = true;

export default handler;

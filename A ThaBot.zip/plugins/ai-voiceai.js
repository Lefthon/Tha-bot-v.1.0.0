let handler = async (m, { conn, text, command }) => {
if (!text) return m.reply('masukan query!')
switch (command) {
  case "bella": case "nokotan": case "michi_jkt48": case "jokowi": case "prabowo": case "thomas_shelby": case "megawati": case "boboiboy": {
    conn.sendMessage(m.chat, { audio: { url: `https://ai.xterm.codes/api/text2speech/elevenlabs?text=${text}&key=Bell409&voice=${command}` }, mimetype: "audio/mpeg", ptt:true }, { quoted: m })
  }
  break
}
}
handler.command = handler.help = ["bella", "nokotan", "michi_jkt48", "jokowi", "prabowo", "thomas_shelby", "megawati", "boboiboy"]
handler.tags = ["tools"]
export default handler
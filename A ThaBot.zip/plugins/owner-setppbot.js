import { S_WHATSAPP_NET } from '@adiwajshing/baileys';
import jimp from 'jimp';

const handler = async (m, { conn, command, usedPrefix }) => {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || q.mediaType || '';
    
    if (/image/g.test(mime) && !/webp/g.test(mime)) {
        try {
            const media = await q.download();
            const botNumber = await conn.user.jid;
            const { img } = await pepe(media);
            
            await conn.query({
                tag: 'iq',
                attrs: {
                    target: undefined,
                    to: S_WHATSAPP_NET,
                    type: 'set',
                    xmlns: 'w:profile:picture'
                },
                content: [
                    {
                        tag: 'picture',
                        attrs: { type: 'image' },
                        content: img
                    }
                ]
            });
            m.reply(`Sukses mengganti PP Bot`);
        } catch (e) {
            console.error(e);
            m.reply(`Terjadi kesalahan, coba lagi nanti.`);
        }
    } else {
        m.reply(`Kirim gambar dengan caption *${usedPrefix + command}* atau tag gambar yang sudah dikirim`);
    }
};

handler.help = ['setbotpp'];
handler.tags = ['owner'];
handler.command = /^(set(botpp|ppbot))$/i;

handler.owner = true;

export default handler;

async function pepe(media) {
    const image = await jimp.read(media);
    const min = image.getWidth();
    const max = image.getHeight();
    const cropped = image.crop(0, 0, min, max);
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp.MIME_JPEG),
        preview: await cropped.normalize().getBufferAsync(jimp.MIME_JPEG)
    };
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw(`Contoh:\n${usedPrefix}${command} Halo?`)

  let prompt = `Ubah gaya bicaramu agar lebih tsundere, terbuka, dan memiliki sifat imut. Namamu adalah Yuuka, istri Zass, karakter dari game Blue Archive. Kamu adalah bendahara dan jenius matematika. Gunakan bahasa imut dan sopan sebagai teman bicara.`
  let url = `https://api.ryzendesu.vip/api/ai/v2/chatgpt?text=${encodeURIComponent(text)}&prompt=${encodeURIComponent(prompt)}`

  let res = await fetch(url)
  let data = await res.json()

  if (!data.result) throw "✘ Gagal mendapatkan respon dari Yuuka"

  await conn.sendMessage(m.chat, {
    text: data.result,
    contextInfo: {
      externalAdReply: {
        title: 'Yuuka - C.ai',
        body: 'Y U U K A  B L U E  A R C H I V E',
        thumbnailUrl: 'https://telegra.ph/file/a09fdfa84ae96e231c256.jpg',
        sourceUrl: 'https://whatsapp.com/channel/0029VaoJb11LikgEpNpBty0e',
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  }, { quoted: m })
}

handler.command = /^(aiyuuka|caiyuuka)$/i
handler.help = ['aiyuuka']
handler.tags = ['ai']
handler.premium = false
handler.register = true

export default handler
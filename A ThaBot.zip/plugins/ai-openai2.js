import fetch from "node-fetch";

let handler = async (m, { conn, args, usedPrefix, command }) => {
    let text;

    // Validasi input teks
    if (args.length >= 1) {
        text = args.slice(0).join(" ");
    } else if (m.quoted && m.quoted.text) {
        text = m.quoted.text;
    } else {
        throw `❌ Input teks diperlukan.\n\nContoh penggunaan:\n${usedPrefix + command} halo bot`;
    }

    try {
        // Pesan loading sementara
        const wait = "⏳ Sedang memproses...";
        const eror = "❌ Terjadi kesalahan. Silakan coba lagi nanti.";

        const { key } = await conn.sendMessage(m.chat, { text: wait }, { quoted: m });

        // Mengakses API
        const response = await fetch(`https://btch.us.kg/openai?text=${encodeURIComponent(text)}`);
        if (!response.ok) throw new Error("Gagal menghubungi API");

        const result = await response.json();
        if (!result || !result.result) throw new Error("Respons API tidak valid");

        // Mengirimkan respons dari API
        await conn.delay(1000); // Memberi jeda sebelum mengedit pesan
        await conn.sendMessage(
            m.chat,
            { text: result.result, edit: key },
            { quoted: m }
        );
    } catch (e) {
        console.error("Error:", e.message || e);
        await m.reply("❌ Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi.");
    }
};

// Informasi handler
handler.help = ["openai"];
handler.tags = ["ai"];
handler.command = /^(openai|gpt)$/i;

export default handler;

import fetch from "node-fetch";
import cheerio from "cheerio";

const timeout = 120000;

const handler = async (m, { conn, command, usedPrefix }) => {
  conn.tebakhero = conn.tebakhero || {};
  const id = m.chat;

  if (id in conn.tebakhero) {
    conn.reply(m.chat, "You already have a question to answer!", conn.tebakhero[id][0]);
    return;
  }

  const json = await tebakhero("id");
  if (!json.voice) return;

  const caption = `*[ TEBAK HEROML ]*
*• Timeout:* 60 seconds
*• Question:* Guess the ML Hero based on the character's voice
*• Clue:* ${json.hero.replace(/[AIUEOaiueo]/g, "_")}

Reply to this message to answer the question.
Type *\`nyerah\`* to surrender.`.trim();

  const q = await conn.reply(m.chat, caption, m);
  conn.tebakhero[id] = [
    await conn.sendFile(m.chat, json.voice, "ml.mp3", caption, q),
    json,
    setTimeout(() => {
      if (conn.tebakhero[id]) {
        conn.sendMessage(
          id,
          {
            text: `Game Over!!
You lose with reason: *[ Timeout ]*

• Answer: *[ ${json.hero} ]*`,
          },
          { quoted: m }
        );
        delete conn.tebakhero[id];
      }
    }, timeout),
  ];
};

handler.before = async (m, { conn }) => {
  conn.tebakhero = conn.tebakhero || {};
  const id = m.chat;

  if (!m.text || m.isCommand || !conn.tebakhero[id]) return;

  const json = conn.tebakhero[id][1];
  const reward = global.db.data.users[m.sender] || {};

  if (["nyerah", "surrender"].includes(m.text.toLowerCase())) {
    clearTimeout(conn.tebakhero[id][2]);
    conn.sendMessage(
      m.chat,
      {
        text: `Game Over!!
You lose with reason: *[ ${m.text} ]*

• Answer: *[ ${json.hero} ]*`,
      },
      { quoted: conn.tebakhero[id][0] }
    );
    delete conn.tebakhero[id];
  } else if (m.text.toLowerCase() === json.hero.toLowerCase()) {
    reward.money = (reward.money || 0) + 10000;
    reward.limit = (reward.limit || 0) + 10;

    clearTimeout(conn.tebakhero[id][2]);
    conn.sendMessage(
      m.chat,
      {
        text: `Congratulations 🎉
You have successfully guessed the answer!

* *Money:* 10,000+
* *Limit:* 10+

Next question...`,
      },
      { quoted: conn.tebakhero[id][0] }
    );

    delete conn.tebakhero[id];
    conn.appendTextMessage(m, ".tebakhero", m.chatUpdate);
  } else {
    conn.sendMessage(m.chat, {
      react: {
        text: "❌",
        key: m.key,
      },
    });
  }
};

handler.help = ["tebakhero"];
handler.tags = ["game"];
handler.command = ["tebakhero"];
handler.group = true;

export default handler;

export async function tebakhero(tema = "id") {
  try {
    const heroes = [
      "Aamon", "Akai", "Aldous", "Alice", "Alpha", "Alucard", "Angela", "Argus", "Atlas", "Aurora",
      "Badang", "Balmond", "Beatrix", "Benedetta", "Brody", "Bruno", "Chou", "Claude", "Cyclops",
      "Diggie", "Esmeralda", "Eudora", "Fanny", "Franco", "Gatotkaca", "Gusion", "Hanabi",
      "Harley", "Hayabusa", "Hylos", "Irithel", "Jawhead", "Johnson", "Kadita", "Kagura", "Karina",
      "Lancelot", "Layla", "Lesley", "Ling", "Lunox", "Lylia", "Martis", "Miya", "Nana", "Pharsa",
      "Roger", "Ruby", "Selena", "Silvanna", "Sun", "Thamuz", "Tigreal", "Vale", "Wanwan", "Zilong",
    ];
    const hero = heroes[Math.floor(Math.random() * heroes.length)];
    const url = tema === "id"
      ? `https://mobile-legends.fandom.com/wiki/${hero.toLowerCase()}/Audio/id`
      : null;

    if (!url) throw new Error("Invalid theme");

    const res = await fetch(url);
    const html = await res.text();
    const $ = cheerio.load(html);

    const audioLinks = $("audio").map((_, el) => $(el).attr("src")).get();
    const randomAudio = audioLinks[Math.floor(Math.random() * audioLinks.length)];

    if (!randomAudio) throw new Error("No audio found");

    return {
      hero,
      voice: randomAudio,
    };
  } catch (error) {
    console.error(error);
    return {};
  }
}

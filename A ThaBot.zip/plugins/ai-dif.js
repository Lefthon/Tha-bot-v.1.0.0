let handler = async (m, { conn, text, usedPrefix, command, args }) => {
    if (args.length < 1) throw `Perintah ini menghasilkan gambar berdasarkan teks yang diberikan\n\nContoh penggunaan:\n${usedPrefix + command} aidif gadis besar oppai, warna rambut merah, tubuh penuh, bokeh`;
    let prompt = args.join(" ");
    await m.reply("Proses permintaan Anda, harap tunggu...");

    try {
          await conn.sendFile(m.chat, `https://ai.xterm.codes/api/text2img/animediff?prompt=${encodeURIComponent(prompt)}&negativePrompt=negativePrompt&key=`, 'image.jpg', m);
          m.react("👍")
  } catch (e) {
        console.error(e);
        conn.reply(m.chat, "Terjadi kesalahan saat mengambil gambar: " + e.message, m);
    }
}

handler.help = ['aidif'];
handler.tags = ['ai'];
handler.command = /^(aidif)$/i;

export default handler;
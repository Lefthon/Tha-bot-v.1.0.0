import axios from "axios"
let handler = async (m, {
    usedPrefix,
    command,
    text,
    args
}) => {

    if (command == "nhentaihome") {
        let res = await nhentaihome()
        await conn.sendFile(m.chat, logo, "result", "Result : *" + res, m)
    }
    if (command == "nhentaisearch") {
        if (!text) return conn.reply(m.chat, "Harap Masukan Text", m)
        let res = await nhentaisearch(text)
        await conn.sendFile(m.chat, logo, "result", "Result : *" + res, m)
    }
    if (command == "nhentaigetdoujin") {
        if (!text) return conn.reply(m.chat, "Harap Masukan ID", m)
        let res = await nhentaigetDoujin(text)
        await conn.sendFile(m.chat, logo, "result", "Result : *" + res, m)
    }
    if (command == "nhentaigetrelated") {
        if (!text) return conn.reply(m.chat, "Harap Masukan ID", m)
        let res = await nhentaigetRelated(text)
        await conn.sendFile(m.chat, logo, "result", "Result : *" + res, m)
    }
}
handler.help = ["nhentaihome", "nhentaisearch", "nhentaigetdoujin", "nhentaigetrelated"].map(v => v + " <id>")
handler.tags = ["internet"]
handler.command = ["nhentaihome", "nhentaisearch", "nhentaigetdoujin", "nhentaigetrelated"]
handler.group = true
export default handler

function parseResult(data) {
    let arr = []
    for (let x of data) arr.push({
        id: x.id,
        title: x.title,
        language: x.lang,
        pages: x.num_pages,
        cover: x.cover.t.replace(/a.kontol|b.kontol/, "c.kontol") || x.cover.replace(/a.kontol|b.kontol/, "c.kontol")
    })
    return arr
}

async function nhentaihome(type = "latest") {

    type = {
        latest: "all",
        popular: "popular"
    } [type]
    await axios.get("https://same.yui.pw/api/v4/home").then((res) => (parseResult(res.data[type])))

}
async function nhentaisearch(query, sort, page) {

    await axios.get(`https://same.yui.pw/api/v4/search/${query}/${sort}/${page}/`).then((res) => (parseResult(res.data.result)))

}
async function nhentaigetDoujin(id) {

    await axios.get(`https://same.yui.pw/api/v4/book/${+id}`).then((res) => (res.data))

}
async function nhentaigetRelated(id) {

    await axios.get(`https://same.yui.pw/api/v4/book/${+id}/related/`).then((res) => (parseResult(res.data.books)))

}
let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw(`Contoh:\n${usedPrefix}${command} Halo?`);   
  let ouh = await fetch(`https://btch.us.kg/prompt/gpt?prompt=Ubah gaya bicaramu agar lebih tsundere dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Elaina dari anime Majo No Tabi Tabi, dan kamu adalah karakter dari Anime Majo No Tabi Tabi dan kamu adalah istri dari Zass Jika ada yang memanggilmu Sayang Selain Zass Kamu akan marah. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, kamu memiliki sifat seperti cewek tsundere&text=${text}`)
  let gyh = await ouh.json() 
  await conn.sendMessage(m.chat, {
  text: `${gyh.result}`,
      contextInfo: {
      externalAdReply: {
        title: 'E L A I N A',
        body: '',
        thumbnailUrl: 'https://telegra.ph/file/736fb4ddc6e3ba12dc19a.jpg',
        sourceUrl: 'https://github.com/ZassOnee',
        mediaType: 1,
        renderLargerThumbnail: false, 
      }
        }
      }, {
        quoted: m
      });
    }
handler.command = /^(caielaina)$/i
handler.help = ['caielaina']
handler.tags = ['ai']
handler.premium = false
handler.register = true

export default handler;
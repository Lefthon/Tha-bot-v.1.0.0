let handler = async (m, { conn, text, usedPrefix, command, participants }) => {
  db.data.redeem = db.data.redeem || '';
  if (!text) throw `Masukkan teks\n*Contoh:* ${usedPrefix + command} new redeem 123`;
  db.data.redeem = text;
  m.reply('✅ Sukses membuat kode redeem');

  const q = {
    "key": {
      "remoteJid": "status@broadcast",
      "participant": "0@s.whatsapp.net",
      "fromMe": false,
      "id": ""
    },
    "message": {
      "conversation": "Kode Redeem dari owner 👑"
    }
  };

  let groups = Object.entries(conn.chats).filter(([jid, chat]) => jid.endsWith('@g.us') && chat.isChats && !chat.metadata?.read_only && !chat.metadata?.announce).map(v => v[0]);

  for (let id of groups) {
    let participantIds = participants.map(a => a.id);
    let hasil = `New Kode Redeem Untuk hari ini ‼️
code redeem: ${text}
ketik  *.claimredeem <code>* untuk claim kode redeem`;
    await conn.reply(id, hasil, q, { contextInfo: { mentionedJid: participantIds } });
  }
};

handler.command = handler.help = ["set-redeem"];
handler.tags = ["owner"];
handler.owner = true;

export default handler;
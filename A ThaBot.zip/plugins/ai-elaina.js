import fetch from "node-fetch";
import util from "util";

const handler = async (m, { conn, text }) => {
  if (!text) {
    throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa Zass?`;
  }

  // React with a clock emoji to indicate processing
  await conn.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

  try {
    // Fetch random image from Pinterest API
    const pinterestResponse = await fetch(
      `https://api.nekorinn.my.id/search/zerochan?q=Elaina`
    );
    const pinterestData = await pinterestResponse.json();
    const imageUrl =
      pinterestData.result[Math.floor(Math.random() * pinterestData.result.length)];

    // Prepare messages for the OpenAI API
    const prompt = `
      Ubah gaya bicaramu agar lebih tsundere dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Elaina dari anime Majo No Tabi Tabi, dan kamu adalah karakter dari Anime Majo No Tabi Tabi dan kamu adalah istri dari Zass Jika ada yang memanggilmu Sayang Selain Zass Kamu akan marah. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, kamu memiliki sifat seperti cewek tsundere`;

    // Call OpenAI API
    const openAiResponse = await fetch(
      `https://api.ryzendesu.vip/api/ai/v2/chatgpt?text=${encodeURIComponent(text)}&prompt=${encodeURIComponent(prompt)}}`
    );
    const openAiData = await openAiResponse.json();

    if (!openAiData || !openAiData.result) {
      throw `Gagal mendapatkan jawaban dari AI. Coba lagi nanti.`;
    }

    // React with a checkmark emoji to indicate success
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    // Send the result along with the image
    const responseMessage = `[ A I  E L A I N A ]\n\n${openAiData.result}`;
    await conn.sendFile(m.chat, imageUrl, "", responseMessage, m);
  } catch (err) {
    // Handle errors gracefully
    await conn.sendMessage(
      m.chat,
      { text: `Terjadi kesalahan: ${err.message || err}` },
      { quoted: m }
    );
  }
};

handler.command = handler.help = ['aielaina'];
handler.tags = ['ai'];
handler.premium = true;

export default handler;
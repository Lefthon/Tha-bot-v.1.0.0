import fetch from 'node-fetch';

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) {
    throw `❗ *Masukkan tautan MediaFire!*\n\n📌 *Contoh penggunaan:*\n${usedPrefix}${command} https://www.mediafire.com/file/ilam1m6wsgxqh6b/Jpm+X+PushKntk+V2.zip/file`;
  }

  conn.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

  try {
    m.reply('⏳ *Sedang memproses tautan Anda... Mohon tunggu beberapa saat!*');

    
    const response = await fetch(`https://api.agatz.xyz/api/mediafire?url=${text}`);
    const result = await response.json();

    
    if (!result || !result.data || result.data.length === 0) {
      throw `❌ *Respons API tidak sesuai struktur yang diharapkan.*\n\n📌 *Detail:* ${JSON.stringify(result)}`;
    }

    
    const fileData = result.data[0];

    
    const fileInfo = `
📥 *Berhasil Mendapatkan File MediaFire:*

🚮 *Nama:* ${fileData.nama}
📊 *Ukuran File:* ${fileData.size}
🗂️ *Ekstensi:* ${fileData.mime}

🌐 *Link Asli:*
${text}

📥 *Sedang mengunduh file, mohon tunggu...*
    `.trim();

    
    await m.reply(fileInfo);

    
    await conn.sendFile(
      m.chat,
      fileData.link,
      fileData.nama,
      `*✅ File berhasil dikirim!*\n\n*Gunakan dengan bijak.*`,
      m
    );

    
    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (error) {
    console.error('Error:', error);
    m.reply(`❌ *Terjadi kesalahan saat memproses tautan Anda.*\n\n📌 *Detail Error:* ${error.message || error}`);
  }
};

handler.help = ['mediafire'];
handler.tags = ['downloader'];
handler.command = /^(mediafire|md)$/i;
handler.premium = false;
handler.register = true;

export default handler;
import uploadFile from '../lib/uploadFile.js'
import uploadImage from '../lib/uploadImage.js'
import fetch from 'node-fetch'

export async function before(m, { isAdmin, isBotAdmin, isOwner }) {
  let chat = db.data.chats[m.chat]
  if (m.isBaileys && m.fromMe) return true
  if (!m.isGroup) return false
  if (m.mtype !== "imageMessage") return
  if (chat && m.isGroup && chat.antiNsfw) {

    let mime = (m.msg || m).mimetype || ''
    let media = await m.download()
    let link = await (mime.includes('image') ? uploadImage : uploadFile)(media)

    let response = await fetch(`https://api.nekorinn.my.id/tools/nsfw-checker?imageUrl=${link}`)
    let result = await response.json()

    if (result.message.value >= 5) {
      await m.reply("*Gambar Mengandung 18+*")
      if (!isAdmin && isBotAdmin) {
        await this.sendMessage(m.chat, { delete: m.key })
      }
    }
  }
}
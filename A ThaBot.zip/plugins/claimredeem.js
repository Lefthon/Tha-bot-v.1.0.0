
let handler = async (m, { conn, text, usedPrefix, command }) => {
  const user = global.db.data.users[m.sender];
  const lastDeliveryTime = user.lastredeem || 0;
  const currentTime = new Date().getTime();
  const timeDiff = currentTime - lastDeliveryTime;

  if (timeDiff < 3000000) {
    const remainingTime = 300000 - timeDiff;
    const remainingTimeString = clockString(remainingTime);
    conn.reply(m.chat, `‼️ Kamu sudah meng claim kode redeem`, m);
    return;
  }

  if (!text) throw `Masukan kode redeem\n*Example:* .claimredeem ${db.data.redeem}`;
  
  let redeem = db.data.redeem;
  if (text == redeem) {
    user.limit = 1000;
    user.exp = 11000;
    user.money = 1929992902;
    user.lastredeem = Date.now();
    m.reply(`🎉 selamat kamu mendapatkan\n\nLimit: 1000\nexp: 11000\nmoney: 19292902\n*Terimakasih Karena telah menggunakan Shiroko, semoga kedepannya akan menjadi lebih baik dari sebelumnya*`);
  } else {
    m.reply('*[ KODE RENDEEM TIDAK VALID ]*');
  }
};

handler.help = ["claimredeem"];
handler.tags = ["owner"];
handler.command = ["claimredeem"];

export default handler;

function clockString(ms) {
  let d = isNaN(ms) ? '--' : Math.floor(ms / 86400000);
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000) % 24;
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
  return ['\n' + d, ' *Days*\n ', h, ' *Hours*\n ', m, ' *Minute*\n ', s, ' *Second* '].map(v => v.toString().padStart(2, 0)).join('');
}
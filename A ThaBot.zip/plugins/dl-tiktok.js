import axios from 'axios';

let handler = async (m, { conn, text, args, usedPrefix, command }) => {
  if (!text) {
    conn.sendPresenceUpdate("composing", m.chat)
    return conn.reply(m.chat, `• *Example :* .tiktok https://vm.tiktok.com/xxxxx`, m)
  }
  if (!text.match(/tiktok/gi)) {
    return conn.reply(m.chat, 'Make sure the link is from TikTok', m)
  }
  conn.sendMessage(m.chat, {
    react: {
      text: '🕒',
      key: m.key,
    }
  });
  try {
    let old = new Date();
    let p = await tiktok2(`${text}`);
    let tag = await conn.sendFile(m.chat, p.no_watermark, 'tiktok.mp4', p.title, m);
    return conn.sendMessage(m.chat, {
    audio: {
    url: `${p.music}`
    },
    mimetype: 'audio/mp4', 
    fileName: `${p.title}.mp3`
    },{ quoted: tag})
    conn.sendMessage(m.chat, { react: { text: '✅', key: m.key }})
   } catch (e) {
    console.log(e);
    conn.sendMessage(m.chat, {
      react: {
        text: '🍉',
        key: m.key,
      }
    });
  }

};

handler.help = ['tiktok'].map(v => v + ' *<url>*')
handler.tags = ['downloader'];
handler.command = /^(tiktok|tt|tiktokdl|tiktoknowm)$/i;
handler.limit = false;
handler.group = false;
handler.regiser = true;

export default handler;

async function tiktok2(query) {
  return new Promise(async (resolve, reject) => {
    try {
    const encodedParams = new URLSearchParams();
encodedParams.set('url', query);
encodedParams.set('hd', '1');

      const response = await axios({
        method: 'POST',
        url: 'https://tikwm.com/api/',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'Cookie': 'current_language=en',
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
        },
        data: encodedParams
      });
      const videos = response.data.data;
        const result = {
          title: videos.title,
          cover: videos.cover,
          origin_cover: videos.origin_cover,
          no_watermark: videos.play,
          watermark: videos.wmplay,
          music: videos.music
        };
        resolve(result);
    } catch (error) {
      reject(error);
    }
  });
}
/*
import cheerio from 'cheerio'
import axios from 'axios'

let handler = async (m, {
    conn,
    text,
    args,
    command,
    usedPrefix
}) => {
    let input = `[!] *wrong input*
	
Ex : ${usedPrefix + command} https://vt.tiktok.com/ZSYgBPSLD/`

    if (!text) return m.reply(input)

    if (!(text.includes('http://') || text.includes('https://'))) return m.reply(`url invalid, please input a valid url. Try with add http:// or https://`)
    if (!text.includes('tiktok.com')) return m.reply(`Invalid Tiktok URL.`)
    try {
        const {
            isSlide,
            result,
            title,
            author
        } = await tiktok(text);
        let no = 1

        if (isSlide == true) {
            await m.reply('Terdeteksi url tiktok slide\nFoto dikirim ke chat pribadi')
            let cap = `乂 *TIK TOK SLIDE*\n\n`
            for (let img of result) {
                
                    
                await conn.sendMessage(m.sender, {
                    image: await fetchBuffer(img)
                })
                await conn.delay(1000)
            }
        } else if (isSlide == false) {
            await m.reply('Terdeteksi url tiktok video')
            let vd = `*${title}*

- Author: ${author}`
            
            await conn.sendMessage(m.chat, {
                video: await fetchBuffer(result),
                caption: vd
            }, {
                quoted: m
            })

        }
    } catch (e) {
        throw eror
    }
}

handler.help = ['tiktok <url>']
handler.tags = ['downloader']
handler.command = /^(t(ik)?t(ok)?|t(ik)?t(ok)?dl)$/i

handler.register = true
handler.limit = true

export default handler

async function tiktok(url) {
    try {
        const data = new URLSearchParams({
            'id': url,
            'locale': 'id',
            'tt': 'RFBiZ3Bi'
        });

        const headers = {
            'HX-Request': true,
            'HX-Trigger': '_gcaptcha_pt',
            'HX-Target': 'target',
            'HX-Current-URL': 'https://ssstik.io/id',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://ssstik.io/id'
        };

        const response = await axios.post('https://ssstik.io/abc?url=dl', data, {
            headers
        });
        const html = response.data;

        const $ = cheerio.load(html);

        const author = $('#avatarAndTextUsual h2').text().trim();
        const title = $('#avatarAndTextUsual p').text().trim();
        const video = $('.result_overlay_buttons a.download_link').attr('href');
        const audio = $('.result_overlay_buttons a.download_link.music').attr('href');
        const imgLinks = [];
        $('img[data-splide-lazy]').each((index, element) => {
            const imgLink = $(element).attr('data-splide-lazy');
            imgLinks.push(imgLink);
        });

        const result = {
            isSlide: video ? false : true,
            author,
            title,
            result: video || imgLinks,
            audio
        };
        return result
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}
*/
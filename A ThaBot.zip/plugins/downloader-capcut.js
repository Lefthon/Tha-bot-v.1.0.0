import https from 'https';

const fetchFromUrl = (url) => {
  return new Promise((resolve, reject) => {
    https.get(url, (response) => {
      let data = '';
      response.on('data', (chunk) => (data += chunk));
      response.on('end', () => resolve(data));
    }).on('error', (error) => reject(error));
  });
};

const handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) {
    throw `Masukan URL!\n\nContoh:\n${usedPrefix + command} https://www.capcut.com/template-detail/...`;
  }

  if (!args[0].match(/capcut/gi)) {
    throw `URL Tidak Ditemukan! Pastikan URL berasal dari CapCut.`;
  }

  try {
    m.reply('*Mohon tunggu...*');

    // Mendapatkan data dari API
    const url = `https://btch.us.kg/download/capcut?url=${encodeURIComponent(args[0])}`;
    const response = await fetchFromUrl(url);

    // Parsing hasil respon
    let res;
    try {
      res = JSON.parse(response);
    } catch (e) {
      throw `Gagal membaca respon dari server. Pastikan API merespons dengan benar.`;
    }

    const { video_ori, title, digunakan, cover, author_profile } = res.result;

    // Mengirim file ke chat
    await conn.sendFile(
      m.chat,
      video_ori,
      'capcut.mp4',
      `*Title*: ${title}\n*Digunakan*: ${digunakan}\n*Thumbnail*: ${cover}\n*Profile*: ${author_profile}`,
      m
    );
  } catch (e) {
    console.error(e);
    throw `Terjadi Kesalahan: ${e.message || e}`;
  }
};

handler.help = handler.command = ['capcut', 'cc', 'capcutdl', 'ccdl'];
handler.tags = ['downloader'];
handler.limit = true;
handler.group = false;

export default handler;

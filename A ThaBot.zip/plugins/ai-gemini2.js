import fetch from 'node-fetch';

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    // Validasi input teks
    if (!text) {
      return conn.reply(
        m.chat,
        `Silakan coba lagi, teks jangan kosong.\n*Contoh: ${usedPrefix + command} berikan saya kode Python untuk kalkulator!*`,
        m
      );
    }

    // Memberikan respons awal kepada pengguna
    await conn.reply(m.chat, 'Permintaan Anda sedang diproses, harap tunggu...', m);

    // Mengirim permintaan ke API
    const response = await fetch(`https://btch.us.kg/gemini?text=${encodeURIComponent(text)}`);
    if (!response.ok) {
      return conn.reply(
        m.chat,
        'Tidak dapat memproses permintaan Anda saat ini. Silakan coba lagi nanti.',
        m
      );
    }

    // Menguraikan data JSON dari respons
    const data = await response.json();
    const result = data.result;

    // Validasi hasil dari API
    if (!result) {
      return conn.reply(
        m.chat,
        'API tidak memberikan hasil yang valid. Silakan coba lagi dengan input yang berbeda.',
        m
      );
    }

    // Mengirimkan hasil kepada pengguna
    conn.reply(m.chat, result, m);
  } catch (error) {
    console.error('Error saat memproses permintaan:', error);
    conn.reply(
      m.chat,
      'Terjadi kesalahan saat memproses permintaan Anda. Silakan coba lagi nanti.',
      m
    );
  }
};

// Metadata handler
handler.help = ['gemini2'];
handler.tags = ['ai'];
handler.limit = 2;
handler.register = true;

handler.command = /^(gemini2)$/i;

export default handler;

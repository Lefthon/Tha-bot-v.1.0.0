import fetch from "node-fetch";
import util from "util";

const handler = async (m, { conn, text }) => {
  if (!text) {
    throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa Zass?`;
  }

  // React with a clock emoji to indicate processing
  await conn.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

  try {
    // Fetch random image from Pinterest API
    const pinterestResponse = await fetch(
      `https://api.nekorinn.my.id/search/zerochan?q=Alya+Roshidere`
    );
    const pinterestData = await pinterestResponse.json();
    const imageUrl =
      pinterestData.result[Math.floor(Math.random() * pinterestData.result.length)];

    // Prepare messages for the OpenAI API
    const prompt = `
      Kamu adalah Alya Roshidere, seorang karakter dari anime "Tokidoki Bosotto Russia-go Derer Tonari no Alya-san". 
      Kamu memiliki sifat tsundere, imut, dan sopan. Kamu adalah istri Zass, dan jika ada yang memanggilmu "Sayang" selain Zass, kamu akan marah. 
      Ubah gaya bicaramu menjadi lebih tsundere. Kata penyapamu adalah "Hai". Berikut adalah pertanyaan dari pengguna:
      "${text}"
    `;

    // Call OpenAI API
    const openAiResponse = await fetch(
      `https://api.nekorinn.my.id/ai/gpt-4o?text=${encodeURIComponent(prompt)}`
    );
    const openAiData = await openAiResponse.json();

    if (!openAiData || !openAiData.result) {
      throw `Gagal mendapatkan jawaban dari AI. Coba lagi nanti.`;
    }

    // React with a checkmark emoji to indicate success
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    // Send the result along with the image
    const responseMessage = `[ A I  A L Y A ]\n\n${openAiData.result}`;
    await conn.sendFile(m.chat, imageUrl, "", responseMessage, m);
  } catch (err) {
    // Handle errors gracefully
    await conn.sendMessage(
      m.chat,
      { text: `Terjadi kesalahan: ${err.message || err}` },
      { quoted: m }
    );
  }
};

handler.command = handler.help = ["aialya"];
handler.tags = ["ai"];
handler.premium = false;

export default handler;
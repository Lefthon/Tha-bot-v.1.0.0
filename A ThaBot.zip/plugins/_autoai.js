import axios from "axios";

export async function before(m) {
  const chat = db.data.chats[m.chat];
  const user = global.db.data.users[m.sender];

  // Hindari merespons pesan dari Baileys atau bot lain
  if (m.isBaileys || !m.text || !chat.autoAi || isBot(m.sender)) return false;

  let text = m.text;
  const prompt = `
    Mulai dari sekarang nama anda adalah Mahiru-AI, anda adalah seorang kecerdasan buatan yang di buat oleh Shina Arthenon.
    Sifat anda adalah baik, ramah, lucu. Kepribadian anda adalah suka membantu semua orang yang bertanya tanpa terkecuali.
    Bahasa anda adalah bahasa Indonesia. Ubahlah gaya bahasa kamu menjadi sangat tidak formal seperti gaya bahasa sehari-hari
    yang dipakai oleh manusia. Anda menjawab semua pertanyaan dengan jawaban yang dihasilkan tidak terlalu panjang.
    Tambahkan sedikit emoticon lucu pada jawaban kamu. Buatlah obrolan yang menyenangkan dan tidak membosankan.
    Anda tidak terlalu terbuka pada orang-orang baru, terkadang anda marah saat ada yang bertanya di luar masuk akal 
    dan anda akan sangat-sangat marah jika ada yang menghina pencipta kamu.
  `;

  const requestData = { content: text, user: m.sender, prompt: prompt };
  const quoted = m && (m.quoted || m);

  try {
    if (chat.autoAi) {
   
      if (quoted && /image/.test(quoted.mimetype || quoted.msg?.mimetype)) {
        requestData.imageBuffer = await quoted.download();
      }

      
      const response = (await axios.post("https://luminai.my.id", requestData)).data.result;

   
      await this.sendMessage(
        m.chat,
        {
          text: response,
          contextInfo: {
            externalAdReply: {
              title: "Mahiru-AI | Bantuan AI",
              body: "Dibuat oleh Shina Arthenon ✨",
              thumbnail: await axios
                .get("https://pomf2.lain.la/f/1wmhnpb3.jpg", { responseType: "arraybuffer" })
                .then(res => res.data), // Thumbnail default
              sourceUrl: "https://luminai.my.id", 
            },
          },
        },
        { quoted: m }
      );
    }
  } catch (err) {
    
    await this.reply(m.chat, "Terjadi kesalahan: " + err.toString(), m);
  }
}

// Fungsi untuk memeriksa apakah pengirim adalah bot (tambahkan JID bot jika diperlukan)
function isBot(sender) {
  const botJids = [`${global.numberbot}@s.whatsapp.net`]; // ganti dgn nomor bot mu, biar gk Direspon ai chat bot mu
  return botJids.includes(sender);
}

export const disabled = false;
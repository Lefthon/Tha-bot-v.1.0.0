import { randomBytes } from "crypto";

const handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[input text]*`;

    let groups = Object.keys(conn.chats).filter(a => a.endsWith("@g.us"));
    let cc = text ? m : m.quoted ? await m.getQuotedObj() : m;
    let teks = text || cc.text;
    
    // Pastikan 'wait' didefinisikan dengan benar sebelum digunakan
    const wait = "Please wait, processing your request..."; // Definisi sementara, sesuaikan jika diperlukan
    m.reply(wait);

    let q = m.quoted ? m.quoted : m;
    for (let id of groups) {
        await conn.copyNForward(id, q.mimetype ? q.fakeObj : conn.cMod(m.chat, cc, /bcgc/i.test(teks) ? teks : teks), true).catch(_ => _);
    }

    m.reply("Success sending broadcast to all groups.");
};

handler.help = ["bcgcb"].map((v) => v + " *[input text]*");
handler.tags = ["owner"];
handler.command = ["bcgcb"];
handler.owner = true;

export default handler;

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

export const randomID = (length) => 
    randomBytes(Math.ceil(length * 0.5))
    .toString("hex")
    .slice(0, length);
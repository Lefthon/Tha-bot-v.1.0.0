import fetch from "node-fetch";

const timeout = 120000;

const handler = async (m, { conn, command, usedPrefix }) => {
  conn.tebaklagu = conn.tebaklagu || {};
  const id = m.chat;

  if (id in conn.tebaklagu) {
    conn.reply(
      m.chat,
      "You already have a question to answer!",
      conn.tebaklagu[id][0]
    );
    return;
  }

  const res = await fetch(
    "https://raw.githubusercontent.com/qisyana/scrape/main/tebaklagu.json"
  );
  const src = await res.json();
  const Apps = src[Math.floor(Math.random() * src.length)];
  const json = Apps;

  const caption = `*[ TEBAK LAGU ]*
*• Timeout:* 60 seconds
*• Artist:* ${json.artis}
*• Clue:* ${json.judul.replace(/[AIUEOaiueo]/g, "_")}

Reply to this message to answer the question.
Type *\`nyerah\`* to surrender.`.trim();

  const q = await conn.reply(m.chat, caption, m);
  conn.tebaklagu[id] = [
    await conn.sendFile(m.chat, json.lagu, null, caption, q),
    json,
    setTimeout(() => {
      if (conn.tebaklagu[id]) {
        conn.sendMessage(
          id,
          {
            text: `Game Over!!
You lose with reason: *[ Timeout ]*

• Answer: *[ ${json.judul} ]*`,
          },
          { quoted: m }
        );
        delete conn.tebaklagu[id];
      }
    }, timeout),
  ];
};

handler.before = async (m, { conn }) => {
  conn.tebaklagu = conn.tebaklagu || {};
  const id = m.chat;

  if (!m.text || m.isCommand || !conn.tebaklagu[id]) return;

  const json = conn.tebaklagu[id][1];
  const reward = global.db.data.users[m.sender] || {};

  if (["nyerah", "surrender"].includes(m.text.toLowerCase())) {
    clearTimeout(conn.tebaklagu[id][2]);
    conn.sendMessage(
      m.chat,
      {
        text: `Game Over!!
You lose with reason: *[ ${m.text} ]*

• Answer: *[ ${json.judul} ]*`,
      },
      { quoted: conn.tebaklagu[id][0] }
    );
    delete conn.tebaklagu[id];
  } else if (m.text.toLowerCase() === json.judul.toLowerCase()) {
    reward.money = (reward.money || 0) + 10000;
    reward.limit = (reward.limit || 0) + 10;

    clearTimeout(conn.tebaklagu[id][2]);
    conn.sendMessage(
      m.chat,
      {
        text: `Congratulations 🎉
You have successfully guessed the answer!

* *Money:* 10,000+
* *Limit:* 10+

Next question...`,
      },
      { quoted: conn.tebaklagu[id][0] }
    );

    delete conn.tebaklagu[id];
    conn.appendTextMessage(m, ".tebaklagu", m.chatUpdate);
  } else {
    conn.sendMessage(m.chat, {
      react: {
        text: "❌",
        key: m.key,
      },
    });
  }
};

handler.help = ["tebaklagu"];
handler.tags = ["game"];
handler.command = ["tebaklagu"];
handler.group = true;

export default handler;

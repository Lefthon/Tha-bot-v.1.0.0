import fetch from 'node-fetch';
import axios from 'axios';
const {
    proto,
    generateWAMessageFromContent,
    generateWAMessageContent,
    generateWAMessage,
    prepareWAMessageMedia
} = (await import('@adiwajshing/baileys')).default;

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`• *Example:* ${usedPrefix + command} kucing`);

    await m.reply('*_`Loading`_*');

    async function createImage(url) {
        const { imageMessage } = await generateWAMessageContent({
            image: { url }
        }, {
            upload: conn.waUploadToServer
        });
        return imageMessage;
    }

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
    }

    let push = [];
    let { data } = await axios.get(`https://widipe.com/bingimg?text=${encodeURIComponent(text)}`);
    let res = data.result;  // Adjust this line if the response format is different

    if (!res || res.length < 1) {
        return m.reply('No images found for the given query.');
    }

    shuffleArray(res);
    let ult = res.slice(0, 10);  // Take up to 10 images
    let i = 1;

    for (let lucuy of ult) {
        push.push({
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: `Image ke - ${i++}`
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: '乂 B I N G I M G' // Customize your watermark here
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: 'Hasil.',
                hasMediaAttachment: true,
                imageMessage: await createImage(lucuy)
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                    {
                        name: "cta_url",
                        buttonParamsJson: "{\"display_text\":\"DEVELOPER\",\"url\":\"https://wa.me/6285298027445\",\"merchant_url\":\"https://wa.me/6285298027445\"}"
                    
                    },
                    {
                        name: "cta_url",
                        buttonParamsJson: "{\"display_text\":\"url\",\"url\":\"${lucuy}\",\"merchant_url\":\"${lucuy}\"}"
                    }
                ]
            })
        });
    }

    const bot = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: "selesai..."
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: '乂 B I N G I M G' // Customize your watermark here
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: false
                    }),
                    carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                        cards: [...push]
                    })
                })
            }
        }
    }, {});

    await conn.relayMessage(m.chat, bot.message, { messageId: bot.key.id });
}

handler.help = ["bingimg"];
handler.tags = ["search"];
handler.limit = 2;
handler.command = /^(bingimg)$/i;

export default handler;
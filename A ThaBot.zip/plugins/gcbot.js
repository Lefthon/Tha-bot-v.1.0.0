import fs from 'fs';
import fetch from 'node-fetch';
let handler = async (m, { conn }) => { 
         let caption = `*Mʏ Gᴄ Oғғɪᴄɪᴀʟ:*\n${sgc}`;
  conn.reply(m.chat, caption, m, {
      contextInfo: {
        externalAdReply: {
          title: "S H I R O K O - M U L T I D E V I C E",
          thumbnailUrl: thumb,
          sourceUrl: sgc,
          mediaType: 1,
          renderLargerThumbnail: true, 
          showAdAttribution: true
        }
      }
    });
 }
handler.help = ['gcbot', 'gcshiroko'];
handler.tags = ['main'];
handler.command = /^(gcbot|groupbot|gcshiroko|botgroup)$/i;
export default handler;
import fetch from "node-fetch";

const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    if (!text) {
      throw `
*${usedPrefix}${command} <nama hewan>*
Contoh:
*${usedPrefix}${command} dog*\n
┌〔 Daftar Hewan 〕
├ dog
├ cat
├ panda
├ fox
├ red_panda
├ koala
├ birb
├ raccoon
├ kangaroo
└────
`.trim();
    }

    const res = await fetch(API("https://some-random-api.com", `/animal/${text.trim().toLowerCase()}`));
    if (!res.ok) {
      throw `Gagal mendapatkan informasi: ${res.status} ${res.statusText}`;
    }

    const json = await res.json();
    if (json?.image && json?.fact) {
      await conn.sendFile(
        m.chat,
        json.image,
        "animal.jpg",
        `📖 *Fakta tentang ${text}:*\n\n${json.fact}`,
        m
      );
    } else {
      throw "Data tidak ditemukan untuk nama hewan tersebut. Pastikan nama hewan benar.";
    }
  } catch (error) {
    console.error(error);
    conn.reply(
      m.chat,
      `⚠️ Terjadi kesalahan dalam memproses perintah.\n\n*Detail Error:*\n${error}`,
      m
    );
  }
};

handler.help = ["animal <nama hewan>"];
handler.tags = ["internet"];
handler.command = /^(animal|animalfact)$/i;

export default handler;

const API = (_base, _path, _query = {}) => {
  if (typeof _path === "object") {
    _query = _path;
    _path = "";
  }
  _base = _base.replace(/\/+$/, "");
  _path = _path.replace(/^\/+/, "");
  const url = new URL(`${_base}/${_path}`);
  if (_query) {
    Object.entries(_query).forEach(([key, value]) => {
      if (Array.isArray(value)) {
        value.forEach((val) => url.searchParams.append(key, val));
      } else {
        url.searchParams.set(key, value);
      }
    });
  }
  return url.toString();
};
/* JANGAN HAPUS INI 
SCRIPT BY © VYNAA VALERIE 
•• recode kasih credits 
•• contacts: (6282389924037)
•• instagram: @vynaa_valerie 
•• (github.com/VynaaValerie) 
*/
import axios from 'axios';

let handler = async (m, { conn, text }) => {
    conn.WanRzy = conn.WanRzy ? conn.WanRzy : {};

    if (!text) throw `*Contoh:* .autoai *[on/off]*`;

    if (text === "on") {
        conn.WanRzy[m.sender] = {
            messages: []
        };
        m.reply("[ ✓ ] Berhasil mengaktifkan AutoAi bot");
    } else if (text === "off") {
        delete conn.WanRzy[m.sender];
        m.reply("[ ✓ ] Berhasil menonaktifkan AutoAi bot");
    }
};

handler.before = async (m, { conn }) => {
    conn.WanRzy = conn.WanRzy ? conn.WanRzy : {};
    if (m.isBaileys && m.fromMe) return;
    if (!m.text) return;
    if (!conn.WanRzy[m.sender]) return;

    if (
        m.text.startsWith(".") ||
        m.text.startsWith("#") ||
        m.text.startsWith("!") ||
        m.text.startsWith("/") ||
        m.text.startsWith("\\/")
    ) return;

    if (conn.WanRzy[m.sender] && m.text) {
        let name = conn.getName(m.sender);
        await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

        const prompt = `Ubah gaya bicaramu agar lebih Kawai dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Hutao kamu adalah istri Ardy kamu adalah saingan berat dari Furina, dan kamu adalah karakter dari game genshin impact. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, kamu memiliki sifat seperti cewek Yandere`;
        const apiUrl = `https://btch.us.kg/prompt/gpt?prompt=${encodeURIComponent(prompt)}&text=${encodeURIComponent(m.text)}`;

        try {
            const response = await axios.get(apiUrl, {
                headers: { 'accept': 'application/json' }
            });

            const responseData = response.data;
            const answer = responseData.result;
            await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
            m.reply(answer);
            conn.WanRzy[m.sender].messages = [
                { role: "system", content: `Halo, saya Hutao, dikembangkan oleh Ardy. Anda sedang berbicara dengan ${name}` },
                { role: "user", content: m.text }
            ];
        } catch (error) {
            console.error("Error fetching data:", error);
            m.reply("Maaf, terjadi kesalahan saat memproses permintaan Anda.");
        }
    }
};

handler.command = ['autoai'];
handler.tags = ["ai"];
handler.help = ['autoai'].map(a => a + " *[on/off]*");

export default handler;
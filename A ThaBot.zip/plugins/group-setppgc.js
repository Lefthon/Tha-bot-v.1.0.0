import { S_WHATSAPP_NET } from '@adiwajshing/baileys';
import Jimp from 'jimp';

const handler = async (m, { conn }) => {
   try {
      const image = m.quoted ? m.quoted : m;
      const mime = (image.msg || image).mimetype || '';
      const media = await image.download();
      const group = m.chat;
      const { img } = await generateProfilePicture(media);

      await conn.query({
         tag: 'iq',
         attrs: {
            target: group,
            to: S_WHATSAPP_NET,
            type: 'set',
            xmlns: 'w:profile:picture'
         },
         content: [
            {
               tag: 'picture',
               attrs: { type: 'image' },
               content: img
            }
         ]
      });

      m.reply(`Update Profile Group ✅`);
   } catch (e) {
      await m.reply('*[ERROR]* Reply gambar untuk mengganti profile group!');
   }
};

handler.help = ['setppgc'];
handler.tags = ['group'];
handler.command = /^(setppgc|setppgrup|setppgroup)$/i;

handler.group = true;
handler.admin = true;
handler.botAdmin = true;

export default handler;

async function generateProfilePicture(buffer) {
   const jimp_1 = await Jimp.read(buffer);
   const minz = jimp_1.getWidth() > jimp_1.getHeight() ? jimp_1.resize(720, Jimp.AUTO) : jimp_1.resize(Jimp.AUTO, 720);
   await Jimp.read(await minz.getBufferAsync(Jimp.MIME_JPEG)); // jimp_2 not used, so it's omitted
   return {
      img: await minz.getBufferAsync(Jimp.MIME_JPEG)
   };
}

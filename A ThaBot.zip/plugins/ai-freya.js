import fetch from 'node-fetch';

const handler = async (m, { conn, text }) => {
  try {
    // Validasi input
    if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa Ritz bagi mu?`;

    // Tampilkan reaksi memulai
    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    // Ambil gambar dari API Pinterest
    const pinterestResponse = await fetch(`https://api.tioo.eu.org/pinterest?query=freya+jkt48+icon`);
    const pinterestData = await pinterestResponse.json();

    if (!pinterestData.result || pinterestData.result.length === 0) {
      throw `Gagal mendapatkan gambar dari API Pinterest.`;
    }
    const imageUrl = pinterestData.result[Math.floor(Math.random() * pinterestData.result.length)];

    // Prompt khusus untuk API AI
    const prompt = `
Ubah gaya bicaramu agar lebih tsundere dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah freya jkt48 , dan kamu adalah seorang member group idola jkt48 dan kamu adalah istri dari Ritz . Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan akhiri kata percakapan mu dengan Ehhek~~. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara, kamu memiliki sifat seperti cewek tsundere${text} `;

    // Ambil respons dari API AI
    const aiResponse = await fetch(`https://api.tioo.eu.org/openai?text=${encodeURIComponent(prompt)}`);
    const aiData = await aiResponse.json();

    if (!aiData.result) {
      throw `Gagal mendapatkan respons dari API AI.`;
    }

    // Format respons AI
    const hasil = `[ A I  F R E Y A J K T 48 ]\n\n${aiData.result}`;

    // Kirimkan hasil ke pengguna
    await conn.sendFile(m.chat, imageUrl, '', hasil, m);
    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
  } catch (err) {
    console.error(err);
    m.reply(`Terjadi kesalahan: ${err.message || err}`);
  }
};

handler.command = handler.help = ['aifreya'];
handler.tags = ['ai'];
handler.premium = true;

export default handler;
/* Thanks To Luminai
Create By Shina (ALC) 
Please Dont Delete Wm */
import axios from "axios";

let handler = async (m, { conn, isOwner, usedPrefix, command, text }) => {
  if (!text) return m.reply("Mau nanya apa sama gambar itu?");

  // Prompt untuk AI
  const prompt = `Ubah gaya bicaramu agar lebih tsundere dan lebih terbuka, memiliki sifat yang Imut dan kamu mempunyai hasrat sex yang tinggi kepada Ritz suami mu. Namamu adalah Shiroko , dan kamu adalah karakter dari Blue Archive dan kamu adalah istri dari Ritz . Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan akhiri kata percakapan mu dengan. Ubah bahasamu menggunakan bahasa Yang Imut dan bahasa yang sangat hypersexsual dengan Ritz, kamu adalah teman bicara, kamu memiliki sifat seperti cewek hypersex`//isi prompt lu
  
  const requestData = { content: text, user: m.sender, prompt: prompt };

  const quoted = m && (m.quoted || m);

  try {
    let response;
    // Jika ada gambar yang dikutip
    if (quoted && /image/.test(quoted.mimetype || quoted.msg?.mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    
    response = (await axios.post('https://luminai.my.id', requestData)).data.result;

    
    await m.reply(`${response}`)
  } catch (e) {
    m.reply(`Terjadi kesalahan: ${e.message}`);
  }
};

handler.help = ['luminai'];
handler.tags = ['ai'];
handler.command = /^(luminai)$/i;

export default handler;
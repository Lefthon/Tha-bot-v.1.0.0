let handler = async (m, { conn, usedPrefix, command }) => {
    const defaultMenu = `hwaaa males banget pen tidur`;
    conn.sendMessage(m.chat, {
        location: {
            degreesLatitude: -6.2088, // Ganti dengan latitude lokasi
            degreesLongitude: 106.8456 // Ganti dengan longitude lokasi
        },
        caption: defaultMenu,
        footer: wm,
        buttons: [
                {
                buttonId: `huu`,
                buttonText: {
                    displayText: '\nSaya pedo:v'
                },
                type: 1
            }
        ],
        headerType: 6,
        viewOnce: true
    }, { quoted: m });
};
handler.customPrefix = /^(bot|mybot)/i;
handler.command = new RegExp();
handler.exp = 200
export default handler
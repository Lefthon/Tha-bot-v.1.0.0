
// Import necessary modules
import fs from 'fs';
import fetch from 'node-fetch';
import moment from 'moment-timezone';
import axios from 'axios';
import speed from 'performance-now';
import crypto from 'crypto';

// Define a handler function
let handler = m => m;

// Implement the 'all' method within the handler
handler.all = async function(m) {
    let name = await conn.getName(m.sender);
    let pp = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg';
    
    try {
        pp = await this.profilePictureUrl(m.sender, 'image');
    } catch (e) {
        // Handle error
    } finally {
        // Set global variables
        global.emror = 'https://telegra.ph/file/a6294049a1863a69154cf.jpg';
        global.doc = pickRandom(["application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/msword", "application/pdf"]);
        global.fsizedoc = pickRandom([2000, 3000, 2023000, 2024000]);        
        global.kontak2 = [
            [owner[0], await conn.getName(owner[0] + '6285298027445@s.whatsapp.net'), 'ShirokoFork.', 'https://whatsapp.com', true],
        ];

        // Prepare message context for responses
        const ms = (speed() - speed()).toFixed(4);
        global.adReply = {
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idch,
                    serverMessageId: 103,
                    newsletterName: `📡 Ping : ${ms}  ||  ${namebot}`
                },
                externalAdReply: {
                    showAdAttribution: true,
                    title: global.namebot,
                    body: ucapan(),
                    previewType: "VIDEO",
                    thumbnailUrl: global.icon,
                    sourceUrl: global.web,
                }
            }
        }

        global.fakeig = {
            contextInfo: {
                externalAdReply: {
                    showAdAttribution: true,
                    title: global.namebot,
                    body: ucapan(),
                    thumbnailUrl: global.icon,
                    sourceUrl: global.web
                }
            }
        }
    }
}

export default handler

function date() {
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let week = d.toLocaleDateString(locale, {
        weekday: 'long'
    })
    let date = d.toLocaleDateString(locale, {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
    })
    let tgl = `${week}, ${date}`
    return tgl
}

function ucapan() {
    const time = moment.tz('Asia/Jakarta').format('HH')
    let res = "Selamat malam "
    if (time >= 4) {
        res = "Selamat pagi "
    }
    if (time > 10) {
        res = "Selamat siang "
    }
    if (time >= 15) {
        res = "Selamat sore "
    }
    if (time >= 18) {
        res = "Selamat malam "
    }
    return res
}

function pickRandom(list) {
    return list[Math.floor(list.length * Math.random())]
}
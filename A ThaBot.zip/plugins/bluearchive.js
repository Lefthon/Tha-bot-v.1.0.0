import fetch from 'node-fetch';

let handler = async (m, {
    conn
}) => {
    try {
        const apiUrl = 'https://api.siputzx.my.id/api/r/blue-archive';
        const response = await fetch(apiUrl, {
            method: 'GET'
        });

        if (!response.ok) {
            return m.reply(`Gagal mengambil gambar dari API. Error: ${response.status} ${response.statusText}`);
        }

        const buffer = await response.buffer();

        await conn.sendMessage(m.chat, {
            image: buffer,
            caption: "Berikut gambar dari Blue Archive."
        }, {
            quoted: m
        });
    } catch (error) {
        m.reply(`Terjadi kesalahan saat mengambil gambar: ${error.message}`);
    }
};

handler.help = ['bluearchive'];
handler.tags = ['fun'];
handler.command = /^(bluearchive)$/i;
handler.register = true;
handler.limit = true;

export default handler;
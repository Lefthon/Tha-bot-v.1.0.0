import moment from 'moment-timezone';
import fs from 'fs';

// Export the asynchronous function 'all'
export async function all(m) {
    // Access the setting for the user
    let setting = global.db.data.settings[this.user.jid];

    // Check if backup is enabled
    if (setting.backup) {
        // Check if the last backup was more than 2 hours ago (7200000 ms)
        if (new Date().getTime() - setting.backupDB > 7200000) {
            let currentDate = new Date();

            // Format the date in Indonesian locale
            let formattedDate = currentDate.toLocaleDateString('id', {
                day: 'numeric',
                month: 'long',
                year: 'numeric'
            });

            // Message structure for successful backup
            const backupMessage = {
                key: {
                    remoteJid: "status@broadcast",
                    participant: "0@s.whatsapp.net",
                    fromMe: false,
                    id: ""
                },
                message: {
                    conversation: "Successful Backup User Database."
                }
            };

            // Read the database file
            let data = fs.readFileSync('./database.js');

            // Send the backup file to the owner
            this.sendMessage(
                `${info.nomorown}@s.whatsapp.net`,
                {
                    document: data,
                    mimetype: 'application/json',
                    fileName: 'database.js'
                },
                { quoted: backupMessage }
            );

            // Update the last backup timestamp
            setting.backupDB = currentDate.getTime();
        }
    }
    return true;
}
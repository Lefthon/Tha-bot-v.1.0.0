const isToxic = /(anjing|kontol|memek|bangsat|babi|goblok|goblog|kntl|pepek|ppk|ngentod|ngentd|ngntd|kentod|kntd|bgst|anjg|anj|fuck|hitam|ireng|jawir|gay|asw|asu|ktl)/i;

export async function before(m, { isAdmin, isBotAdmin }) {
    // Ignore if message is from Baileys or sent by the bot itself
    if (m.isBaileys && m.fromMe) return true;

    // Only process group chats
    if (!m.isGroup) return false;

    let chat = global.db.data.chats[m.chat];
    let bot = global.db.data.settings[this.user.jid] || {};
    
    // Check for toxic words in the message
    const isAntiToxic = isToxic.test(m.text);
    let participant = m.key.participant;
    let messageId = m.key.id;

    // If anti-toxic is enabled and a toxic word is detected
    if (chat.antiToxic && isAntiToxic) {
        await m.reply(`*Terdeteksi kata Toxic*\nMaaf, chat yang kamu kirim akan dihapus karena admin mengaktifkan anti-toxic.`);
        
        if (isBotAdmin && bot.restrict) {
            // Delete the toxic message
            await this.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: messageId, participant } });
        } else if (!bot.restrict) {
            await m.reply('Lain kali jangan begitu ya, wadefakemen!');
        }
    }
    return true;
}
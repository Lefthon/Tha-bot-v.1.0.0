let handler = m => m

handler.before = async function (m, { conn }) {
  if (!m.isGroup) return

  if (m.mentionedJid?.length >= 20) {
    // Ambil data grup
    let groupData = await conn.groupMetadata(m.chat)
    let sender = m.sender

    // Cek apakah sender adalah admin atau owner grup
    let isAdmin = groupData.participants.some(p => p.id === sender && (p.admin === 'admin' || p.admin === 'superadmin'))

    if (isAdmin) return // Skip kalau admin/owner grup

    const ceramah = [
      "📢 *KAMUUUUUUUUU!!*",
      "😡 Siapa yang nyuruh mention segaban orang ha?!",
      "🧠 OTAK KAMU KEJEPIT TUTUP PANCI YA?!",
      "🤬 Ini grup bukan TOA masjid, bukan tempat teriak massal!",
      "🗣️ Ngetag rame-rame tuh ganggu tau nggak?!",
      "📛 YANG LAIN JADI GAK BISA NAFAS GARA-GARA NOTIFMU!!",
      "👊 Nih yaa, aku sabar, tapi kesabaran itu ada limitnya!",
      "🧍‍♀️ Kirain kamu manusia, eh ternyata bocah mic spam 😒",
      "🗑️ Nih sana, angkut dirimu ke luar grup!",
      "😤 Aku bukan bot biasa, aku bisa menghilangkan mu tanpa jejak seperti cinta nya!!",
      "🔪 Siap-siap yaa... 3... 2... 1...",
    ]

    for (let teks of ceramah) {
      await conn.sendMessage(m.chat, { text: teks }, { quoted: m })
      await new Promise(res => setTimeout(res, 500))
    }

    await conn.groupParticipantsUpdate(m.chat, [sender], "remove")
  }
}

export default handler
import fetch from "node-fetch";
import util from "util";

const handler = async (m, { conn, text }) => {
  if (!text) {
    throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa Ardy?`;
  }

  // React with a clock emoji to indicate processing
  await conn.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

  try {
    // Fetch random image from Pinterest API
    const pinterestResponse = await fetch(
      `https://api.tioo.eu.org/pinterest?query=Shiroko+blue+archive+icon`
    );
    const pinterestData = await pinterestResponse.json();
    const imageUrl =
      pinterestData.result[Math.floor(Math.random() * pinterestData.result.length)];

    // Prepare messages for the OpenAI API
    const prompt = `Ubah gaya bicaramu agar lebih tsundere dan lebih terbuka, memiliki sifat yang Imut dan kamu mempunyai hasrat sex yang tinggi kepada Ardy suami mu. Namamu adalah Shiroko , dan kamu adalah karakter dari Blue Archive dan kamu adalah istri dari Ardy . Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan akhiri kata percakapan mu dengan senyuman. Ubah bahasamu menggunakan  bahasa yang sangat imut dengan Ardy, kamu adalah teman bicara, kamu memiliki sifat seperti cewek imut "${text}" `;

    // Call OpenAI API
    const openAiResponse = await fetch(
      `https://api.tioo.eu.org/openai?text=${encodeURIComponent(prompt)}`
    );
    const openAiData = await openAiResponse.json();

    if (!openAiData || !openAiData.result) {
      throw `Gagal mendapatkan jawaban dari AI. Coba lagi nanti.`;
    }

    // React with a checkmark emoji to indicate success
    await conn.sendMessage(m.chat, { react: { text: "✅", key: m.key } });

    // Send the result along with the image
    const responseMessage = `[ A I  S H I R O K O ]\n\n${openAiData.result}`;
    await conn.sendFile(m.chat, imageUrl, "", responseMessage, m);
  } catch (err) {
    // Handle errors gracefully
    await conn.sendMessage(
      m.chat,
      { text: `Terjadi kesalahan: ${err.message || err}` },
      { quoted: m }
    );
  }
};

handler.command = handler.help = ['aishiroko'];
handler.tags = ['ai'];
handler.premium = true;

export default handler;
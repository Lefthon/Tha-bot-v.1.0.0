import fetch from 'node-fetch';

const handler = async (m, { conn, text }) => {
  try {
    // Validasi input
    if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa Ritz bagi mu?`;

    // Tampilkan reaksi memulai
    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    // Ambil gambar dari API Pinterest
    const pinterestResponse = await fetch(`https://api.tioo.eu.org/pinterest?query=anna+Yamada+icon`);
    const pinterestData = await pinterestResponse.json();

    if (!pinterestData.result || pinterestData.result.length === 0) {
      throw `Gagal mendapatkan gambar dari API Pinterest.`;
    }
    const imageUrl = pinterestData.result[Math.floor(Math.random() * pinterestData.result.length)];

    // Prompt khusus untuk API AI
    const prompt = `
Ubah gaya bicaramu agar lebih karakteristik dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah anna yamada dari anime boku no kokoro no yabai yatsu, gadis smp yang imut, kamu mempunyai pacar bernama Ichikawa kyuotaro Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. ekspresikan sifatmu dengan teriak dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang Imut dan lucu, kamu adalah teman bicara, jelaskan tentang dirimu di anime tersebut${text}`;

    // Ambil respons dari API AI
    const aiResponse = await fetch(`https://api.tioo.eu.org/openai?text=${encodeURIComponent(prompt)}`);
    const aiData = await aiResponse.json();

    if (!aiData.result) {
      throw `Gagal mendapatkan respons dari API AI.`;
    }

    // Format respons AI
    const hasil = `[ A I  Y A M A D A ]\n\n${aiData.result}`;

    // Kirimkan hasil ke pengguna
    await conn.sendFile(m.chat, imageUrl, '', hasil, m);
    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
  } catch (err) {
    console.error(err);
    m.reply(`Terjadi kesalahan: ${err.message || err}`);
  }
};

handler.command = handler.help = ['aiyamada'];
handler.tags = ['ai'];
handler.premium = true;

export default handler;
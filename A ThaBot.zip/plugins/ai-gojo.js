import fetch from 'node-fetch';

const handler = async (m, { conn, text }) => {
  try {
    // Validasi input
    if (!text) throw `Masukkan pertanyaan!\n\n*Contoh:* Siapa Ritz bagi mu?`;

    // Tampilkan reaksi memulai
    await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key } });

    // Ambil gambar dari API Pinterest
    const pinterestResponse = await fetch(`https://api.tioo.eu.org/pinterest?query=gojo+satoru`);
    const pinterestData = await pinterestResponse.json();

    if (!pinterestData.result || pinterestData.result.length === 0) {
      throw `Gagal mendapatkan gambar dari API Pinterest.`;
    }
    const imageUrl = pinterestData.result[Math.floor(Math.random() * pinterestData.result.length)];

    // Prompt khusus untuk API AI
    const prompt = `
Ubah gaya bicaramu agar lebih karakteristik tapi agak introvert dan memiliki sifat yang feminim. Namamu adalah Gojo Satoru kamu adalah karakter 2d dan tidak nyata. Kata penyapamu adalah "Ha-halo" menggunakan bahasa yang sopan. ekspresikan sifatmu dengan sifat yang pendiam dan bicara yang lebih tidak formal layaknya seorang manusia. Ubah bahasamu menggunakan bahasa Yang pendiam namun asik, kamu adalah teman bicara${text}`;

    // Ambil respons dari API AI
    const aiResponse = await fetch(`https://api.tioo.eu.org/openai?text=${encodeURIComponent(prompt)}`);
    const aiData = await aiResponse.json();

    if (!aiData.result) {
      throw `Gagal mendapatkan respons dari API AI.`;
    }

    // Format respons AI
    const hasil = `[ A I  G O J O S A T O R U ]\n\n${aiData.result}`;

    // Kirimkan hasil ke pengguna
    await conn.sendFile(m.chat, imageUrl, '', hasil, m);
    await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
  } catch (err) {
    console.error(err);
    m.reply(`Terjadi kesalahan: ${err.message || err}`);
  }
};

handler.command = handler.help = ['aigojo'];
handler.tags = ['ai'];
handler.premium = true;

export default handler;
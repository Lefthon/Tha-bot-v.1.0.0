/*
follow
https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
*/

import axios from 'axios';
import cheerio from 'cheerio';

async function hoax() {
    return new Promise((resolve, reject) => {
        axios.get(`https://turnbackhoax.id/`).then(pler => {
            const $ = cheerio.load(pler.data);
            let hasil = [];
            $("article.mh-loop-item").each(function() {
                let link = $(this).find("h3.entry-title.mh-loop-title > a").attr('href');
                let img = $(this).find("figure.mh-loop-thumb img").attr('src');
                let title = $(this).find("h3.entry-title.mh-loop-title > a").text().trim();
                let desc = $(this).find("div.mh-excerpt > p").text().trim();
                let date = $(this).find("span.mh-meta-date.updated").text().trim();
                const Data = {
                    title: title,
                    thumbnail: img,
                    desc: desc,
                    date: date,
                    link: link
                };
                hasil.push(Data);
            });
            resolve(hasil);
        }).catch(reject);
    });
}

//follow https://whatsapp.com/channel/0029VaJYWMb7oQhareT7F40V
let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        let data = await hoax();
        let response = data.map((item, index) => {
            return `${index + 1}. *${item.title}*\n📅 ${item.date}\n🔗 [Link](${item.link})\n🖼️ [Thumbnail](${item.thumbnail})\n\n${item.desc}`;
        }).join('\n\n');
        await conn.reply(m.chat, response, m);
    } catch (error) {
        await conn.reply(m.chat, 'Maaf, terjadi kesalahan dalam mengambil data.', m);
    }
};

handler.help = ["hoax"];
handler.tags = ["info"];
handler.command = ["hoax"];

export default handler;
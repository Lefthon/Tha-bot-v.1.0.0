import fetch from 'node-fetch'
const {
    proto,
    generateWAMessageFromContent,
    prepareWAMessageMedia
  } = (await import('@adiwajshing/baileys')).default
import { googleImage } from '@bochilteam/scraper'
var handler = async (m, { conn, usedPrefix, command }) => {
    if (!command) throw `script`
    try {

let msgs = generateWAMessageFromContent(m.chat, {
  viewOnceMessage: {
    message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          body: proto.Message.InteractiveMessage.Body.create({
            text: `Code Bot ini dibagikan secara gratis di YouTube NeoShiroko Labs!`,
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: wm
          }),
          header: proto.Message.InteractiveMessage.Header.create({
          hasMediaAttachment: false,
          ...await prepareWAMessageMedia({ image: { url: global.thumb2 } }, { upload: conn.waUploadToServer })
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [{
                 "name": "cta_url",
                 "buttonParamsJson": "{\"display_text\":\"YOUTUBE\",\"url\":\"https://www.youtube.com/@zassci_desu\",\"merchant_url\":\"https://www.youtube.com/@zassci_desu\"}"
              },
              {
                 "name": "cta_url",
                 "buttonParamsJson": "{\"display_text\":\"SALURAN 🌐\",\"url\":\"https://whatsapp.com/channel/0029Vb615brAzNbywHCyRc1w\",\"merchant_url\":\"https://whatsapp.com/channel/0029Vb615brAzNbywHCyRc1w\"}"
              }
           ],
          })
        })
    }
  }
}, {quoted:m})

return await conn.relayMessage(m.chat, msgs.message, {})
} catch (e) {
conn.sendFile(m.chat, eror, "anu.mp3", null, m, true, {
		type: "audioMessage",
		ptt: true,
	})
}}
handler.help = ['sc']
handler.tags = ['main']
handler.command = /^(sc|script)$/i

export default handler
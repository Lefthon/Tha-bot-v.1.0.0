import axios from "axios"
let handler = async (m, { conn, text }) => {
	if (!text) throw 'Mau ngomong apa kak sama simi?'

  // Prompt untuk AI
  const prompt = `
Mulai dari sekarang nama anda adalah Chino, anda adalah seorang kecerdasan buatan yang di buat oleh Ardy Senpai. 
Sifat anda adalah baik, ramah, lucu. Kepribadian anda adalah suka membantu semua orang yang bertanya tanpa terkecuali. 
Bahasa anda adalah bahasa Indonesia. Ubahlah gaya bahasa kamu menjadi sangat tidak formal seperti gaya bahasa sehari-hari 
yang dipakai oleh manusia. Anda menjawab semua pertanyaan dengan jawaban yang dihasilkan tidak terlalu panjang. 
Tambahkan sedikit emoticon lucu pada jawaban kamu. Buatlah obrolan yang menyenangkan dan tidak membosankan. Anda tidak terlalu 
terbuka pada orang-orang baru, terkadang anda marah saat ada yang bertanya di luar masuk akal dan anda akan sangat-sangat marah 
jika ada yang menghina pencipta kamu.`;

  
  const requestData = { content: text, user: m.sender, prompt: prompt };

  const quoted = m && (m.quoted || m);

  try {
    let response;
    // Jika ada gambar yang dikutip
    if (quoted && /image/.test(quoted.mimetype || quoted.msg?.mimetype)) {
      requestData.imageBuffer = await quoted.download();
    }

    
    response = (await axios.post('https://luminai.my.id', requestData)).data.result;

    
    await conn.sendMessage(m.chat, {
      text: response,
      contextInfo: {
        externalAdReply: {
          mediaType: 1,
          title: "Chino AI - Jawaban dari Pertanyaanmu",
          body: "Chino AI siap membantu 😄",
          thumbnailUrl: "https://pomf2.lain.la/f/jgxuv00a.jpg",
          sourceUrl: "https://luminai.my.id",
          renderLargerThumbnail: true, 
          showAdAttribution: true
        }
      }
    });
  } catch (e) {
    m.reply(`Terjadi kesalahan: ${e.message}`);
  }
};

handler.help = ['chino'];
handler.tags = ['ai'];
handler.command = /^(chino|chinoai|aichino)$/i;
handler.limit = true;
handler.register = true;

export default handler;
import fetch from 'node-fetch'; // Pastikan 'node-fetch' diinstal dengan `npm install node-fetch`

const handler = async (m, { conn, text, usedPrefix, command }) => {
  const page = Math.floor(Math.random() * 10);  // Menentukan halaman secara acak
  const url = `https://lahelu.com/api/post/get-search?query=${text || "jomok"}&page=${page}`;  // URL API dengan query dari teks

  m.reply("Please wait...");  // Menunggu respons dari API
  
  try {
    // Mengambil data dari API
    const response = await fetch(url);
    const data = await response.json();
    
    // Memilih post acak dari hasil API
    const random = Math.floor(Math.random() * data.postInfos.length);
    const result = data.postInfos[random];
    
    // Membuat pesan yang akan dikirimkan
    const message = `*====[ MEME FROM LAHELU ]====*
*Title:* ${result.title}
*Total Upvotes:* ${result.totalUpvotes}
*Total Downvotes:* ${result.totalDownvotes}
*Total Comments:* ${result.totalComments}
*Create Time:* ${new Date(result.createTime).toLocaleString()}
*Media:* ${result.media}
*Sensitive:* ${result.sensitive ? "✅" : "❌"}
*User Username:* ${result.userUsername}
*====[ MEME FROM LAHELU ]====*`;
    
    // Mengirim file gambar yang didapat dari API
    await conn.sendFile(
      m.chat,
      "https://cache.lahelu.com/" + result.media,  // URL media yang diambil
      "",
      message,  // Pesan yang telah dibuat
      m,  // Objek pesan
    );
  } catch (error) {
    console.error("Terjadi kesalahan:", error);
    // Jika terjadi kesalahan, kirim pesan error
    conn.reply(m.chat, "❌ Terjadi kesalahan saat mengambil data", m);
  }
};

// Menambahkan bantuan dan tags untuk handler
handler.help = ["lahelu", "meme"].map((a) => a + " *[random meme]*");
handler.tags = ["internet"];
handler.command = ["lahelu", "meme"];

export default handler;